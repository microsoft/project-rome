//
//  Copyright (c) Microsoft Corporation. All rights reserved.
//

#define __MCD_VISIBLE_EXTERNALLY __attribute__((visibility("default")))
