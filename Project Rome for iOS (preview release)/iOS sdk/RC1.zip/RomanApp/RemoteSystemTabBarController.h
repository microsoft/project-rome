//
//  Copyright (c) Microsoft Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RemoteSystemTabBarController : UITabBarController

@end
